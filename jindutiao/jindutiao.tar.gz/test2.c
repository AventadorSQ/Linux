#include<stdio.h>
#include<unistd.h>
int main()
{
  printf("hello makefile");
  sleep(3);
  return 0;
}
