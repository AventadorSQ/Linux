#include<stdio.h>
#include<unistd.h>
int main()
{
  printf("hello makefile");
  fflush(stdout);
  sleep(3);
  return 0;
}
