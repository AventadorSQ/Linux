#include<stdio.h>
#include<unistd.h>
int main()
{
  printf("hello makefile\n");
  sleep(3);
  return 0;
}
